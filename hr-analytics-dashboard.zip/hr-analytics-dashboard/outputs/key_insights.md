# Key Insights

1. **Overall attrition is 16.8%** - 1,680 of 10,000 employees left.
2. **Sales has the highest attrition (22.5%)**; Marketing the lowest (14.1%).
3. **Overtime is the biggest single lever**: 27.3% of overtime workers left vs 12.9% of others (2.1x).
4. **New joiners are most at risk**: employees with 0-1 years' tenure leave at 25.8% vs 9.4% for 10+ years.
5. **Pay matters**: leavers' median income is INR 76,300 vs INR 96,400 for stayers.
6. **Satisfaction**: attrition falls from 27.7% (score 1) to 11.1% (score 4).
7. **Work mode**: Onsite 17.2% | Hybrid 17.2% | Remote 14.9%.
8. **Highest-risk group in the driver table: 'Works overtime'** - 27.3% attrition (2.1x the rate of employees without it).

## Recommendations
- Cap sustained overtime and review workloads in Sales and Technology.
- Build a structured 90-day onboarding and mentoring programme for new joiners.
- Review pay for employees more than 10% below their peer-group median.
- Run quarterly pulse surveys; trigger manager check-ins when satisfaction scores drop to 1-2.
- Look at the youngest cohort (under 30) separately: career-path and learning offers may help retention.