# Build the dashboard in Power BI (step by step)

The Python script already produces a finished dashboard image. Use this guide to rebuild it as an
**interactive** Power BI report, which is what most data analyst job postings ask for.

## 1. Load the data
1. Open Power BI Desktop > **Get Data > Text/CSV** > pick `data/hr_employee_data_clean.csv` > **Transform Data**.
2. In Power Query, check data types:
   - `HireDate` = Date
   - `MonthlyIncome`, `Age`, `YearsAtCompany` = Whole number
   - `AttritionFlag` = Whole number (0/1)
3. **Close & Apply**.

## 2. Create a Date table (for time analysis)
```DAX
DateTable =
ADDCOLUMNS (
    CALENDAR ( DATE ( 1995, 1, 1 ), DATE ( 2026, 12, 31 ) ),
    "Year", YEAR ( [Date] ),
    "Month", FORMAT ( [Date], "MMM" ),
    "MonthNo", MONTH ( [Date] )
)
```
Model view: link `DateTable[Date]` to `hr_employee_data_clean[HireDate]`.

## 3. DAX measures
Create a table called `_Measures` (Home > Enter Data) and add these:

```DAX
Total Employees = COUNTROWS ( hr_employee_data_clean )

Employees Left = SUM ( hr_employee_data_clean[AttritionFlag] )

Attrition Rate % = DIVIDE ( [Employees Left], [Total Employees] )

Active Employees = [Total Employees] - [Employees Left]

Avg Monthly Income = AVERAGE ( hr_employee_data_clean[MonthlyIncome] )

Avg Tenure (Yrs) = AVERAGE ( hr_employee_data_clean[YearsAtCompany] )

Avg Job Satisfaction = AVERAGE ( hr_employee_data_clean[JobSatisfaction] )

Overtime Attrition % =
CALCULATE ( [Attrition Rate %], hr_employee_data_clean[OverTime] = "Yes" )

Non-Overtime Attrition % =
CALCULATE ( [Attrition Rate %], hr_employee_data_clean[OverTime] = "No" )

Attrition vs Company Avg =
[Attrition Rate %] - CALCULATE ( [Attrition Rate %], ALL ( hr_employee_data_clean ) )

Low Satisfaction Employees =
CALCULATE ( [Total Employees], hr_employee_data_clean[JobSatisfaction] <= 2 )
```

Format `Attrition Rate %` and the two overtime measures as **Percentage, 1 decimal**.

## 4. Page layout (16:9)

| Area | Visual | Fields |
|---|---|---|
| Top row | 6 **Card** visuals | Total Employees, Attrition Rate %, Employees Left, Avg Monthly Income, Avg Tenure, Avg Job Satisfaction |
| Left side | **Slicers** (Department, Location, WorkMode, Gender) | use "Tile" or "Dropdown" style |
| Row 1, left | **Clustered bar** | Axis: Department - Values: Attrition Rate % |
| Row 1, middle | **Column chart** | Axis: TenureBand - Values: Attrition Rate % |
| Row 1, right | **Clustered column** | Axis: JobSatisfaction - Legend: OverTime - Values: Attrition Rate % |
| Row 2, left | **Column chart** | Axis: AgeGroup - Values: Attrition Rate % |
| Row 2, middle | **Donut** | Legend: Attrition - Values: Total Employees |
| Row 2, right | **Matrix** | Rows: Department - Columns: JobLevel - Values: Attrition Rate % (Conditional formatting > Background colour, single blue hue, light to dark) |
| Bottom | **Table** | EmployeeID, Department, JobRole, MonthlyIncome, JobSatisfaction, OverTime (filter: Attrition = No) |

## 4b. Add a drill-through page: "Employee Detail"
- New page > drag `Department` into **Drill through** wells.
- Add a table with the employee columns above, so a manager can right-click a department bar and see its people.

## 5. Formatting tips (these make it look professional)
- Use **one blue** for everything, and **one orange** only for "attrition / left" so colour means something.
- Page background `#FCFCFB`, visuals with a thin light-grey border, 8 px rounded corners.
- Give every visual a plain-English title that states the finding, e.g. "Sales has the highest attrition".
- Turn off gridlines you don't need; keep data labels on bars.
- Sync slicers across pages (View > Sync slicers).
- Take a screenshot of the finished page and save it in `images/powerbi_dashboard.png` for your GitHub README.

## 6. Publish
- **File > Publish > Power BI Service** (free account works) > pin to a dashboard.
- Add the link to your resume and README.
