-- ============================================================================
-- HR Analytics - SQL queries
-- Table: hr_employees  (load data/hr_employee_data_clean.csv into it)
-- Works on SQLite / PostgreSQL / MySQL 8+ (minor syntax notes inline).
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Headline KPIs
-- ---------------------------------------------------------------------------
SELECT
    COUNT(*)                                             AS total_employees,
    SUM(AttritionFlag)                                   AS employees_left,
    ROUND(100.0 * SUM(AttritionFlag) / COUNT(*), 1)      AS attrition_rate_pct,
    ROUND(AVG(MonthlyIncome), 0)                         AS avg_monthly_income,
    ROUND(AVG(YearsAtCompany), 1)                        AS avg_tenure_years,
    ROUND(AVG(JobSatisfaction), 2)                       AS avg_job_satisfaction
FROM hr_employees;

-- ---------------------------------------------------------------------------
-- 2. Attrition by department
-- ---------------------------------------------------------------------------
SELECT
    Department,
    COUNT(*)                                             AS employees,
    SUM(AttritionFlag)                                   AS left_company,
    ROUND(100.0 * SUM(AttritionFlag) / COUNT(*), 1)      AS attrition_rate_pct
FROM hr_employees
GROUP BY Department
ORDER BY attrition_rate_pct DESC;

-- ---------------------------------------------------------------------------
-- 3. Attrition by tenure band (CASE WHEN)
-- ---------------------------------------------------------------------------
SELECT
    CASE
        WHEN YearsAtCompany <= 1 THEN '1. 0-1 yrs'
        WHEN YearsAtCompany <= 3 THEN '2. 2-3 yrs'
        WHEN YearsAtCompany <= 6 THEN '3. 4-6 yrs'
        WHEN YearsAtCompany <= 10 THEN '4. 7-10 yrs'
        ELSE '5. 10+ yrs'
    END                                                  AS tenure_band,
    COUNT(*)                                             AS employees,
    ROUND(100.0 * SUM(AttritionFlag) / COUNT(*), 1)      AS attrition_rate_pct
FROM hr_employees
GROUP BY tenure_band
ORDER BY tenure_band;

-- ---------------------------------------------------------------------------
-- 4. Overtime vs attrition
-- ---------------------------------------------------------------------------
SELECT
    OverTime,
    COUNT(*)                                             AS employees,
    ROUND(100.0 * SUM(AttritionFlag) / COUNT(*), 1)      AS attrition_rate_pct
FROM hr_employees
GROUP BY OverTime;

-- ---------------------------------------------------------------------------
-- 5. Do leavers earn less? Average income: stayers vs leavers, by department
-- ---------------------------------------------------------------------------
SELECT
    Department,
    ROUND(AVG(CASE WHEN AttritionFlag = 0 THEN MonthlyIncome END), 0) AS avg_income_stayed,
    ROUND(AVG(CASE WHEN AttritionFlag = 1 THEN MonthlyIncome END), 0) AS avg_income_left
FROM hr_employees
GROUP BY Department
ORDER BY Department;

-- ---------------------------------------------------------------------------
-- 6. Job roles with the highest attrition (ignore tiny groups with HAVING)
-- ---------------------------------------------------------------------------
SELECT
    JobRole,
    Department,
    COUNT(*)                                             AS employees,
    ROUND(100.0 * SUM(AttritionFlag) / COUNT(*), 1)      AS attrition_rate_pct
FROM hr_employees
GROUP BY JobRole, Department
HAVING COUNT(*) >= 100
ORDER BY attrition_rate_pct DESC
LIMIT 10;

-- ---------------------------------------------------------------------------
-- 7. Window function: rank locations by attrition and compare with company average
-- ---------------------------------------------------------------------------
WITH loc AS (
    SELECT
        Location,
        COUNT(*)                                         AS employees,
        100.0 * SUM(AttritionFlag) / COUNT(*)            AS attrition_rate
    FROM hr_employees
    GROUP BY Location
)
SELECT
    Location,
    employees,
    ROUND(attrition_rate, 1)                                                      AS attrition_rate_pct,
    RANK() OVER (ORDER BY attrition_rate DESC)                                    AS risk_rank,
    ROUND(attrition_rate - (SELECT 100.0 * SUM(AttritionFlag) / COUNT(*)
                            FROM hr_employees), 1)                                AS diff_vs_company_avg
FROM loc
ORDER BY risk_rank;

-- ---------------------------------------------------------------------------
-- 8. Employees paid more than 10% below peers (same department and job level)
--    Uses a CTE + window function (AVG ... OVER PARTITION BY).
-- ---------------------------------------------------------------------------
WITH peer AS (
    SELECT
        EmployeeID, Department, JobLevel, MonthlyIncome, AttritionFlag,
        AVG(MonthlyIncome) OVER (PARTITION BY Department, JobLevel) AS peer_avg_income
    FROM hr_employees
)
SELECT
    CASE WHEN MonthlyIncome < 0.90 * peer_avg_income
         THEN 'Paid >10% below peers' ELSE 'Paid in line / above' END   AS pay_group,
    COUNT(*)                                                           AS employees,
    ROUND(100.0 * SUM(AttritionFlag) / COUNT(*), 1)                    AS attrition_rate_pct
FROM peer
GROUP BY pay_group;

-- ---------------------------------------------------------------------------
-- 9. Satisfaction score vs attrition
-- ---------------------------------------------------------------------------
SELECT
    JobSatisfaction,
    COUNT(*)                                             AS employees,
    ROUND(100.0 * SUM(AttritionFlag) / COUNT(*), 1)      AS attrition_rate_pct
FROM hr_employees
GROUP BY JobSatisfaction
ORDER BY JobSatisfaction;

-- ---------------------------------------------------------------------------
-- 10. High-risk, high-value employees to retain:
--     overtime + low satisfaction + good performers who have not left yet
-- ---------------------------------------------------------------------------
SELECT
    EmployeeID, Department, JobRole, JobLevel, MonthlyIncome,
    JobSatisfaction, WorkLifeBalance, PerformanceRating
FROM hr_employees
WHERE AttritionFlag = 0
  AND OverTime = 'Yes'
  AND JobSatisfaction <= 2
  AND PerformanceRating >= 4
ORDER BY PerformanceRating DESC, MonthlyIncome DESC
LIMIT 25;

-- ---------------------------------------------------------------------------
-- 11. Headcount and attrition by hire year (SQLite: strftime; PostgreSQL: EXTRACT(YEAR FROM HireDate);
--     MySQL: YEAR(HireDate))
-- ---------------------------------------------------------------------------
SELECT
    strftime('%Y', HireDate)                             AS hire_year,
    COUNT(*)                                             AS employees,
    ROUND(100.0 * SUM(AttritionFlag) / COUNT(*), 1)      AS attrition_rate_pct
FROM hr_employees
GROUP BY hire_year
ORDER BY hire_year;
