"""
analysis.py
-----------
End-to-end HR analytics: clean the data, calculate KPIs, find the drivers of
attrition, and build a one-page dashboard (PNG) plus individual charts.

Run (after generate_dataset.py):
    python src/analysis.py

Outputs
    data/hr_employee_data_clean.csv     cleaned dataset (load this into Power BI / Tableau)
    outputs/*.csv                       summary tables used by the charts
    outputs/key_insights.md             auto-written findings
    images/*.png                        individual charts + hr_dashboard.png
"""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # no display needed
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import FancyBboxPatch

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR, OUT_DIR, IMG_DIR = ROOT / "data", ROOT / "outputs", ROOT / "images"
for d in (OUT_DIR, IMG_DIR):
    d.mkdir(exist_ok=True)

# ---------------------------------------------------------------------------
# Visual style (validated categorical slots 1 & 2: blue / orange, light surface)
# ---------------------------------------------------------------------------
SURFACE, INK, INK2, MUTED = "#fcfcfb", "#0b0b0b", "#52514e", "#898781"
GRID, BASELINE = "#e1e0d9", "#c3c2b7"
BLUE, ORANGE = "#2a78d6", "#eb6834"
BLUE_RAMP = LinearSegmentedColormap.from_list("blue_seq", ["#cde2fb", "#6da7ec", "#256abf", "#0d366b"])

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "font.family": "DejaVu Sans", "text.color": INK, "axes.labelcolor": INK2,
    "xtick.color": INK2, "ytick.color": INK2, "axes.edgecolor": BASELINE,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.titlesize": 12, "axes.titleweight": "bold", "axes.titlelocation": "left",
    "axes.titlepad": 12, "axes.labelsize": 9, "xtick.labelsize": 9, "ytick.labelsize": 9,
})


def style_axes(ax, grid_axis="y"):
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.tick_params(length=0)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(BASELINE)


# ---------------------------------------------------------------------------
# 1. Load & clean
# ---------------------------------------------------------------------------
def load_and_clean() -> pd.DataFrame:
    df = pd.read_csv(DATA_DIR / "hr_employee_data.csv", parse_dates=["HireDate"])
    print(f"Loaded {len(df):,} rows, {df.shape[1]} columns")

    # --- quality checks -----------------------------------------------------
    print(f"Duplicate EmployeeIDs : {df.EmployeeID.duplicated().sum()}")
    print("Missing values        :", df.isna().sum()[df.isna().sum() > 0].to_dict())

    # --- fix missing values -------------------------------------------------
    # Commute distance: use the median of the employee's own location
    df["DistanceFromHome"] = df["DistanceFromHome"].fillna(
        df.groupby("Location")["DistanceFromHome"].transform("median")
    )
    # Survey score: use the overall median (3 = "High")
    df["EnvironmentSatisfaction"] = df["EnvironmentSatisfaction"].fillna(
        df["EnvironmentSatisfaction"].median()
    )
    df[["DistanceFromHome", "EnvironmentSatisfaction"]] = (
        df[["DistanceFromHome", "EnvironmentSatisfaction"]].round().astype(int)
    )

    # --- feature engineering ------------------------------------------------
    df["AttritionFlag"] = (df["Attrition"] == "Yes").astype(int)
    df["AgeGroup"] = pd.cut(df["Age"], [0, 24, 34, 44, 54, 100],
                            labels=["Under 25", "25-34", "35-44", "45-54", "55+"])
    df["TenureBand"] = pd.cut(df["YearsAtCompany"], [-1, 1, 3, 6, 10, 100],
                              labels=["0-1 yrs", "2-3 yrs", "4-6 yrs", "7-10 yrs", "10+ yrs"])
    df["IncomeBand"] = pd.cut(df["MonthlyIncome"], [0, 50_000, 80_000, 120_000, 180_000, 10**7],
                              labels=["<50K", "50-80K", "80-120K", "120-180K", "180K+"])
    peer_median = df.groupby(["JobLevel", "Department"])["MonthlyIncome"].transform("median")
    df["IncomeVsPeers"] = (df["MonthlyIncome"] / peer_median).round(3)
    df["AvgSatisfaction"] = df[["JobSatisfaction", "EnvironmentSatisfaction",
                                "RelationshipSatisfaction", "WorkLifeBalance"]].mean(axis=1).round(2)

    df.to_csv(DATA_DIR / "hr_employee_data_clean.csv", index=False)
    print("Cleaned file saved -> data/hr_employee_data_clean.csv")
    return df


def rate(s: pd.Series) -> float:
    """Attrition rate in % for a group."""
    return s.mean() * 100


# ---------------------------------------------------------------------------
# 2. KPIs and summary tables
# ---------------------------------------------------------------------------
def kpis(df):
    return {
        "Total Employees": f"{len(df):,}",
        "Attrition Rate": f"{rate(df.AttritionFlag):.1f}%",
        "Employees Left": f"{df.AttritionFlag.sum():,}",
        "Avg Monthly Income": f"INR {df.MonthlyIncome.mean():,.0f}",
        "Avg Tenure": f"{df.YearsAtCompany.mean():.1f} yrs",
        "Avg Job Satisfaction": f"{df.JobSatisfaction.mean():.2f} / 4",
    }


def driver_table(df) -> pd.DataFrame:
    """Attrition rate for employees who have each risk factor vs those who don't."""
    factors = {
        "Works overtime": df.OverTime == "Yes",
        "Joined within last year": df.YearsAtCompany <= 1,
        "Poor work-life balance (1-2)": df.WorkLifeBalance <= 2,
        "Low job satisfaction (1-2)": df.JobSatisfaction <= 2,
        "Frequent business travel": df.BusinessTravel == "Travel_Frequently",
        "Low environment satisfaction (1-2)": df.EnvironmentSatisfaction <= 2,
        "Paid >10% below peers": df.IncomeVsPeers < 0.90,
        "Commute over 20 km": df.DistanceFromHome > 20,
        "Single": df.MaritalStatus == "Single",
        "5+ yrs since promotion": df.YearsSinceLastPromotion >= 5,
        "No training last year": df.TrainingTimesLastYear == 0,
        "Under 30": df.Age < 30,
    }
    rows = []
    for name, mask in factors.items():
        with_f, without_f = rate(df.loc[mask, "AttritionFlag"]), rate(df.loc[~mask, "AttritionFlag"])
        rows.append({"Factor": name, "Employees": int(mask.sum()),
                     "AttritionRate_With": round(with_f, 1),
                     "AttritionRate_Without": round(without_f, 1),
                     "RiskMultiple": round(with_f / without_f, 2)})
    return pd.DataFrame(rows).sort_values("AttritionRate_With", ascending=False).reset_index(drop=True)


# ---------------------------------------------------------------------------
# 3. Chart functions (each draws onto an axis so they work standalone or in the dashboard)
# ---------------------------------------------------------------------------
def bar_rate(ax, df, col, title, horizontal=False, order=None):
    g = df.groupby(col, observed=True)["AttritionFlag"].mean().mul(100)
    if order is not None:
        g = g.reindex(order)
    overall = rate(df.AttritionFlag)
    if horizontal:
        g = g.sort_values()
        bars = ax.barh(g.index.astype(str), g.values, color=BLUE, height=0.62)
        ax.axvline(overall, color=MUTED, linestyle="--", linewidth=1)
        ax.set_xlim(0, g.max() * 1.22)
        for b, v in zip(bars, g.values):
            ax.text(v + g.max() * 0.015, b.get_y() + b.get_height() / 2, f"{v:.1f}%",
                    va="center", fontsize=9, color=INK)
        ax.text(overall, len(g) - 0.45, f" Company avg {overall:.1f}%", color=INK2, fontsize=8, va="bottom")
        style_axes(ax, "x")
        ax.set_xlabel("Attrition rate (%)")
    else:
        bars = ax.bar(g.index.astype(str), g.values, color=BLUE, width=0.62)
        ax.axhline(overall, color=MUTED, linestyle="--", linewidth=1)
        ax.set_ylim(0, g.max() * 1.22)
        for b, v in zip(bars, g.values):
            ax.text(b.get_x() + b.get_width() / 2, v + g.max() * 0.02, f"{v:.1f}%",
                    ha="center", fontsize=9, color=INK)
        ax.text(len(g) - 0.5, overall, f"Company avg {overall:.1f}%  ", color=INK2,
                fontsize=8, ha="right", va="bottom")
        style_axes(ax, "y")
        ax.set_ylabel("Attrition rate (%)")
    ax.set_title(title)


def chart_satisfaction_overtime(ax, df):
    levels = [1, 2, 3, 4]
    labels = ["1 (Low)", "2", "3", "4 (High)"]
    x = np.arange(len(levels))
    w = 0.36
    for i, (ot, color, name) in enumerate([("No", BLUE, "No overtime"), ("Yes", ORANGE, "Works overtime")]):
        vals = [rate(df[(df.OverTime == ot) & (df.JobSatisfaction == l)]["AttritionFlag"]) for l in levels]
        bars = ax.bar(x + (i - 0.5) * (w + 0.03), vals, w, color=color, label=name)
        for b, v in zip(bars, vals):
            ax.text(b.get_x() + b.get_width() / 2, v + 0.6, f"{v:.0f}%", ha="center", fontsize=8.5, color=INK)
    ax.set_xticks(x, labels)
    ax.set_xlabel("Job satisfaction score")
    ax.set_ylabel("Attrition rate (%)")
    ax.set_ylim(0, ax.get_ylim()[1] * 1.12)
    ax.legend(frameon=False, fontsize=9, loc="upper right")
    style_axes(ax, "y")
    ax.set_title("Overtime + low satisfaction = highest exit risk")


def chart_income_dist(ax, df):
    bins = np.linspace(0, 300_000, 31)
    for flag, color, name in [(0, BLUE, "Stayed"), (1, ORANGE, "Left")]:
        data = df.loc[df.AttritionFlag == flag, "MonthlyIncome"].clip(upper=299_999)
        ax.hist(data, bins=bins, density=True, histtype="stepfilled", color=color,
                alpha=0.55, edgecolor=color, linewidth=1.4, label=f"{name} (median {data.median() / 1000:.0f}K)")
    ax.set_xlabel("Monthly income (INR)")
    ax.set_ylabel("Share of employees")
    ax.xaxis.set_major_formatter(lambda v, _: f"{v / 1000:.0f}K")
    ax.set_yticks([])
    ax.legend(frameon=False, fontsize=9, loc="upper right")
    style_axes(ax, "x")
    ax.set_title("Pay distribution: leavers earn less")


def chart_heatmap(ax, df):
    pt = df.pivot_table(index="Department", columns="JobLevel", values="AttritionFlag",
                        aggfunc="mean", observed=True).mul(100)
    pt = pt.loc[pt.mean(axis=1).sort_values(ascending=False).index]
    im = ax.imshow(pt.values, cmap=BLUE_RAMP, aspect="auto", vmin=5, vmax=pt.values.max())
    ax.set_xticks(range(pt.shape[1]), [f"Level {c}" for c in pt.columns])
    ax.set_yticks(range(pt.shape[0]), pt.index)
    thresh = pt.values.max() * 0.62
    for i in range(pt.shape[0]):
        for j in range(pt.shape[1]):
            v = pt.values[i, j]
            ax.text(j, i, f"{v:.0f}%", ha="center", va="center", fontsize=9,
                    color="white" if v > thresh else INK)
    ax.set_xticks(np.arange(-.5, pt.shape[1]), minor=True)
    ax.set_yticks(np.arange(-.5, pt.shape[0]), minor=True)
    ax.grid(which="minor", color=SURFACE, linewidth=2)
    ax.grid(which="major", visible=False)
    ax.tick_params(which="both", length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.set_title("Attrition % by department and job level")


def chart_drivers(ax, drivers, overall):
    d = drivers.sort_values("AttritionRate_With")
    bars = ax.barh(d.Factor, d.AttritionRate_With, color=BLUE, height=0.62)
    ax.axvline(overall, color=MUTED, linestyle="--", linewidth=1)
    ax.set_xlim(0, d.AttritionRate_With.max() * 1.25)
    for b, v, m in zip(bars, d.AttritionRate_With, d.RiskMultiple):
        ax.text(v + 0.4, b.get_y() + b.get_height() / 2, f"{v:.1f}%  ({m:.1f}x)",
                va="center", fontsize=9, color=INK)
    ax.text(overall, 1.01, f"Company avg {overall:.1f}%", color=INK2, fontsize=8, ha="center", va="bottom",
            transform=ax.get_xaxis_transform())
    ax.set_xlabel("Attrition rate for employees with this factor (%)   |   (x) = vs. employees without it")
    style_axes(ax, "x")
    ax.set_title("Top attrition risk factors")


# ---------------------------------------------------------------------------
# 4. Build outputs
# ---------------------------------------------------------------------------
def save_single(fn, name, figsize=(8, 5), *args, **kwargs):
    fig, ax = plt.subplots(figsize=figsize)
    fn(ax, *args, **kwargs)
    fig.tight_layout()
    fig.savefig(IMG_DIR / name, dpi=150)
    plt.close(fig)


def build_dashboard(df, kpi_values):
    fig = plt.figure(figsize=(18, 12.5))
    fig.suptitle("HR Analytics Dashboard  -  Employee Attrition Overview", x=0.03, y=0.985,
                 ha="left", fontsize=20, fontweight="bold")
    fig.text(0.03, 0.952, "10,000 employees  |  6 departments  |  6 locations  |  synthetic data",
             fontsize=11, color=INK2, ha="left")

    gs = fig.add_gridspec(2, 3, left=0.05, right=0.97, top=0.80, bottom=0.37, hspace=0.55, wspace=0.28)
    gs_bottom = fig.add_gridspec(1, 1, left=0.19, right=0.97, top=0.27, bottom=0.07)  # wider left margin for long labels

    # KPI tiles
    n = len(kpi_values)
    tile_w, gap, x0, y0, tile_h = 0.142, 0.0205, 0.03, 0.855, 0.075
    for i, (label, value) in enumerate(kpi_values.items()):
        x = x0 + i * (tile_w + gap)
        fig.add_artist(FancyBboxPatch((x, y0), tile_w, tile_h, boxstyle="round,pad=0,rounding_size=0.008",
                                      transform=fig.transFigure, facecolor="#f9f9f7",
                                      edgecolor=GRID, linewidth=1.2))
        fig.text(x + 0.012, y0 + tile_h - 0.022, label, fontsize=10, color=INK2, va="center")
        accent = ORANGE if label in ("Attrition Rate", "Employees Left") else INK
        fig.text(x + 0.012, y0 + 0.022, value, fontsize=18, fontweight="bold", color=accent, va="center")

    bar_rate(fig.add_subplot(gs[0, 0]), df, "Department", "Attrition % by department", horizontal=True)
    bar_rate(fig.add_subplot(gs[0, 1]), df, "TenureBand", "Attrition % by tenure: first 2 years are riskiest")
    chart_satisfaction_overtime(fig.add_subplot(gs[0, 2]), df)
    bar_rate(fig.add_subplot(gs[1, 0]), df, "AgeGroup", "Attrition % by age group")
    chart_income_dist(fig.add_subplot(gs[1, 1]), df)
    chart_heatmap(fig.add_subplot(gs[1, 2]), df)
    chart_drivers(fig.add_subplot(gs_bottom[0, 0]), driver_table(df), rate(df.AttritionFlag))

    fig.savefig(IMG_DIR / "hr_dashboard.png", dpi=130)
    plt.close(fig)


def write_insights(df, drivers):
    overall = rate(df.AttritionFlag)
    dept = df.groupby("Department")["AttritionFlag"].mean().mul(100).sort_values(ascending=False)
    ot = df.groupby("OverTime")["AttritionFlag"].mean().mul(100)
    ten = df.groupby("TenureBand", observed=True)["AttritionFlag"].mean().mul(100)
    left, stayed = df[df.AttritionFlag == 1], df[df.AttritionFlag == 0]
    sat = df.groupby("JobSatisfaction")["AttritionFlag"].mean().mul(100)
    wm = df.groupby("WorkMode")["AttritionFlag"].mean().mul(100)
    top = drivers.iloc[0]

    lines = [
        "# Key Insights",
        "",
        f"1. **Overall attrition is {overall:.1f}%** - {df.AttritionFlag.sum():,} of {len(df):,} employees left.",
        f"2. **{dept.index[0]} has the highest attrition ({dept.iloc[0]:.1f}%)**; "
        f"{dept.index[-1]} the lowest ({dept.iloc[-1]:.1f}%).",
        f"3. **Overtime is the biggest single lever**: {ot['Yes']:.1f}% of overtime workers left vs "
        f"{ot['No']:.1f}% of others ({ot['Yes'] / ot['No']:.1f}x).",
        f"4. **New joiners are most at risk**: employees with 0-1 years' tenure leave at {ten.iloc[0]:.1f}% "
        f"vs {ten.iloc[-1]:.1f}% for 10+ years.",
        f"5. **Pay matters**: leavers' median income is INR {left.MonthlyIncome.median():,.0f} vs "
        f"INR {stayed.MonthlyIncome.median():,.0f} for stayers.",
        f"6. **Satisfaction**: attrition falls from {sat.loc[1]:.1f}% (score 1) to {sat.loc[4]:.1f}% (score 4).",
        f"7. **Work mode**: Onsite {wm['Onsite']:.1f}% | Hybrid {wm['Hybrid']:.1f}% | Remote {wm['Remote']:.1f}%.",
        f"8. **Highest-risk group in the driver table: '{top.Factor}'** - {top.AttritionRate_With:.1f}% attrition "
        f"({top.RiskMultiple:.1f}x the rate of employees without it).",
        "",
        "## Recommendations",
        "- Cap sustained overtime and review workloads in Sales and Technology.",
        "- Build a structured 90-day onboarding and mentoring programme for new joiners.",
        "- Review pay for employees more than 10% below their peer-group median.",
        "- Run quarterly pulse surveys; trigger manager check-ins when satisfaction scores drop to 1-2.",
        "- Look at the youngest cohort (under 30) separately: career-path and learning offers may help retention.",
    ]
    (OUT_DIR / "key_insights.md").write_text("\n".join(lines), encoding="utf-8")
    print("\n" + "\n".join(lines))


def main():
    df = load_and_clean()
    overall = rate(df.AttritionFlag)

    print("\n--- KPIs ---")
    kpi_values = kpis(df)
    for k, v in kpi_values.items():
        print(f"{k:22s}{v}")

    # Summary tables (also handy for Power BI)
    for col in ["Department", "JobRole", "Location", "WorkMode", "OverTime", "AgeGroup",
                "TenureBand", "IncomeBand", "BusinessTravel", "MaritalStatus", "Gender"]:
        t = (df.groupby(col, observed=True)
             .agg(Employees=("EmployeeID", "count"), Left=("AttritionFlag", "sum"),
                  AttritionRate=("AttritionFlag", lambda s: round(s.mean() * 100, 1)),
                  AvgIncome=("MonthlyIncome", "mean"))
             .round(0).sort_values("AttritionRate", ascending=False))
        t.to_csv(OUT_DIR / f"attrition_by_{col.lower()}.csv")
    drivers = driver_table(df)
    drivers.to_csv(OUT_DIR / "attrition_risk_factors.csv", index=False)

    # Charts
    save_single(bar_rate, "01_attrition_by_department.png", (8, 5), df, "Department",
                "Attrition % by department", horizontal=True)
    save_single(bar_rate, "02_attrition_by_tenure.png", (8, 5), df, "TenureBand",
                "Attrition % by tenure band")
    save_single(chart_satisfaction_overtime, "03_satisfaction_vs_overtime.png", (8, 5), df)
    save_single(bar_rate, "04_attrition_by_age.png", (8, 5), df, "AgeGroup", "Attrition % by age group")
    save_single(chart_income_dist, "05_income_distribution.png", (8, 5), df)
    save_single(chart_heatmap, "06_dept_level_heatmap.png", (8, 5), df)
    save_single(chart_drivers, "07_risk_factors.png", (11, 6), drivers, overall)
    build_dashboard(df, kpi_values)
    print("\nCharts saved -> images/  (open images/hr_dashboard.png)")

    write_insights(df, drivers)


if __name__ == "__main__":
    main()
