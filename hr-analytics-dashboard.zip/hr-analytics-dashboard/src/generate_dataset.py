"""
generate_dataset.py
-------------------
Generates a synthetic (but realistic) HR dataset of 10,000 employees.

Why synthetic?  Real HR data is confidential.  This generator builds a dataset
with the same kind of columns and relationships you see in real HR data
(e.g. overtime and low satisfaction push attrition up, higher pay and longer
tenure pull it down), so the analysis produces meaningful insights.

Run:
    python src/generate_dataset.py

Output:
    data/hr_employee_data.csv   (10,000 rows)
"""

from pathlib import Path

import numpy as np
import pandas as pd

SEED = 42
N = 10_000
TARGET_ATTRITION = 0.165  # ~16.5% yearly attrition, typical for a large company
REFERENCE_DATE = pd.Timestamp("2026-11-01")

rng = np.random.default_rng(SEED)

# ---------------------------------------------------------------------------
# 1. Organisation structure
# ---------------------------------------------------------------------------
DEPARTMENTS = {
    # department: (share of workforce, role list - LAST role is the manager role)
    "Technology": (0.28, ["Software Engineer", "Data Analyst", "QA Engineer", "DevOps Engineer", "Tech Lead"]),
    "Sales": (0.22, ["Sales Executive", "Sales Representative", "Account Executive", "Sales Manager"]),
    "Operations": (0.18, ["Operations Executive", "Logistics Coordinator", "Supply Chain Analyst", "Operations Manager"]),
    "Finance": (0.11, ["Accountant", "Financial Analyst", "Auditor", "Finance Manager"]),
    "Marketing": (0.11, ["Marketing Executive", "Content Specialist", "SEO Specialist", "Marketing Manager"]),
    "HR": (0.10, ["HR Executive", "Recruiter", "Training Specialist", "HR Manager"]),
}
DEPT_NAMES = list(DEPARTMENTS)
DEPT_P = [DEPARTMENTS[d][0] for d in DEPT_NAMES]

# Monthly income (INR) base by job level and department pay multiplier
LEVEL_BASE_INCOME = {1: 32_000, 2: 55_000, 3: 90_000, 4: 140_000, 5: 220_000}
DEPT_PAY_MULT = {"Technology": 1.15, "Finance": 1.05, "Sales": 1.00,
                 "Marketing": 0.97, "Operations": 0.93, "HR": 0.90}

LOCATIONS = ["Bengaluru", "Hyderabad", "Pune", "Chennai", "Mumbai", "Delhi NCR"]
LOCATION_P = [0.26, 0.18, 0.16, 0.12, 0.14, 0.14]

EDU_FIELDS_BY_DEPT = {
    "Technology": (["Engineering", "Computer Science", "Data Science", "Other"], [0.35, 0.35, 0.22, 0.08]),
    "Sales": (["Business", "Marketing", "Engineering", "Other"], [0.45, 0.30, 0.15, 0.10]),
    "Operations": (["Business", "Engineering", "Supply Chain", "Other"], [0.30, 0.30, 0.30, 0.10]),
    "Finance": (["Commerce", "Business", "Economics", "Other"], [0.50, 0.25, 0.17, 0.08]),
    "Marketing": (["Marketing", "Business", "Communications", "Other"], [0.45, 0.25, 0.22, 0.08]),
    "HR": (["Human Resources", "Business", "Psychology", "Other"], [0.45, 0.30, 0.17, 0.08]),
}

# ---------------------------------------------------------------------------
# 2. Demographics & experience
# ---------------------------------------------------------------------------
age = np.clip(rng.normal(36, 8.5, N).round(), 21, 60).astype(int)
gender = rng.choice(["Male", "Female", "Non-binary"], N, p=[0.56, 0.42, 0.02])
marital = rng.choice(["Single", "Married", "Divorced"], N, p=[0.33, 0.55, 0.12])
education = rng.choice([1, 2, 3, 4, 5], N, p=[0.10, 0.19, 0.39, 0.27, 0.05])  # 1=School ... 5=Doctorate

department = rng.choice(DEPT_NAMES, N, p=DEPT_P)

# Total working years: depends on age (people start working ~21-24)
total_working_years = np.maximum(0, ((age - 21) * rng.uniform(0.55, 1.0, N)).round()).astype(int)

# Job level (1-5) grows with experience
level_score = total_working_years + rng.normal(0, 2.2, N)
job_level = 1 + np.digitize(level_score, [3, 8, 14, 20])

# Years at company cannot exceed total working years
years_at_company = np.minimum(
    total_working_years,
    np.round(rng.exponential(5.0, N) * rng.uniform(0.6, 1.2, N)).astype(int),
)
years_in_role = np.minimum(years_at_company, np.round(rng.exponential(3.0, N)).astype(int))
years_since_promo = np.minimum(
    years_at_company,
    np.round(rng.exponential(2.2, N) + (job_level == 1) * rng.exponential(0.8, N)).astype(int),
)
years_with_manager = np.minimum(years_at_company, np.round(rng.exponential(3.0, N)).astype(int))
num_companies = np.minimum(rng.poisson(2.2, N), np.maximum(1, total_working_years // 2 + 1))

# ---------------------------------------------------------------------------
# 3. Job role, pay, location
# ---------------------------------------------------------------------------
job_role = np.empty(N, dtype=object)
education_field = np.empty(N, dtype=object)
for dept in DEPT_NAMES:
    idx = np.where(department == dept)[0]
    roles = DEPARTMENTS[dept][1]
    junior_roles, manager_role = roles[:-1], roles[-1]
    picks = rng.choice(junior_roles, len(idx))
    is_manager = job_level[idx] >= 4
    picks = np.where(is_manager, manager_role, picks)
    job_role[idx] = picks
    fields, p = EDU_FIELDS_BY_DEPT[dept]
    education_field[idx] = rng.choice(fields, len(idx), p=p)

base = np.array([LEVEL_BASE_INCOME[l] for l in job_level], dtype=float)
mult = np.array([DEPT_PAY_MULT[d] for d in department])
monthly_income = (base * mult * rng.lognormal(0, 0.13, N) / 100).round() * 100
monthly_income = monthly_income.astype(int)

location = rng.choice(LOCATIONS, N, p=LOCATION_P)
work_mode = rng.choice(["Onsite", "Hybrid", "Remote"], N, p=[0.45, 0.38, 0.17])
distance = np.clip(rng.exponential(9, N).round(), 1, 45).astype(int)

# Overtime is more common in Sales and Technology
ot_prob = np.array([{"Sales": 0.34, "Technology": 0.32}.get(d, 0.22) for d in department])
overtime = np.where(rng.random(N) < ot_prob, "Yes", "No")

travel_p = {
    "Sales": [0.08, 0.52, 0.40],
    "Operations": [0.15, 0.60, 0.25],
}
default_travel_p = [0.20, 0.70, 0.10]
business_travel = np.empty(N, dtype=object)
for dept in DEPT_NAMES:
    idx = np.where(department == dept)[0]
    business_travel[idx] = rng.choice(
        ["Non-Travel", "Travel_Rarely", "Travel_Frequently"], len(idx),
        p=travel_p.get(dept, default_travel_p),
    )

# ---------------------------------------------------------------------------
# 4. Surveys & performance
# ---------------------------------------------------------------------------
job_sat = rng.choice([1, 2, 3, 4], N, p=[0.12, 0.20, 0.36, 0.32])
env_sat = rng.choice([1, 2, 3, 4], N, p=[0.12, 0.20, 0.36, 0.32])
rel_sat = rng.choice([1, 2, 3, 4], N, p=[0.10, 0.20, 0.37, 0.33])
# Work-life balance is worse when people work overtime
wlb = np.where(
    overtime == "Yes",
    rng.choice([1, 2, 3, 4], N, p=[0.14, 0.34, 0.37, 0.15]),
    rng.choice([1, 2, 3, 4], N, p=[0.04, 0.16, 0.48, 0.32]),
)
performance = rng.choice([1, 2, 3, 4, 5], N, p=[0.03, 0.12, 0.50, 0.28, 0.07])
salary_hike = np.clip(rng.normal(12, 3.5, N) + (performance - 3) * 2.0, 3, 25).round().astype(int)
training = rng.choice([0, 1, 2, 3, 4, 5, 6], N, p=[0.05, 0.08, 0.30, 0.30, 0.15, 0.08, 0.04])

# ---------------------------------------------------------------------------
# 5. Attrition - generated from a logistic model so patterns are realistic
# ---------------------------------------------------------------------------
median_income = (
    pd.DataFrame({"lvl": job_level, "dept": department, "inc": monthly_income})
    .groupby(["lvl", "dept"])["inc"].transform("median").to_numpy()
)
income_ratio = monthly_income / median_income

z = (
    0.95 * (overtime == "Yes")
    - 0.42 * (job_sat - 2.5)
    - 0.28 * (env_sat - 2.5)
    - 0.38 * (wlb - 2.5)
    + 0.035 * np.maximum(distance - 10, 0)
    - 2.2 * (income_ratio - 1)
    + 0.95 * (years_at_company <= 1)
    + 0.35 * ((years_at_company > 1) & (years_at_company <= 2))
    - 0.05 * years_at_company
    - 0.035 * (age - 36)
    + 0.12 * years_since_promo
    + 0.30 * (num_companies >= 5)
    + 0.60 * (business_travel == "Travel_Frequently")
    + 0.40 * (marital == "Single")
    - 0.30 * (work_mode == "Remote")
    + 0.25 * (training == 0)
    + 0.35 * (department == "Sales")
    + 0.40 * (job_level == 1)
    - 0.12 * (performance - 3)
)

# Find the intercept that gives the target overall attrition rate
lo, hi = -10.0, 10.0
for _ in range(60):
    mid = (lo + hi) / 2
    if (1 / (1 + np.exp(-(z + mid)))).mean() > TARGET_ATTRITION:
        hi = mid
    else:
        lo = mid
prob = 1 / (1 + np.exp(-(z + (lo + hi) / 2)))
attrition = np.where(rng.random(N) < prob, "Yes", "No")

# ---------------------------------------------------------------------------
# 6. Assemble DataFrame
# ---------------------------------------------------------------------------
hire_date = REFERENCE_DATE - pd.to_timedelta(
    years_at_company * 365 + rng.integers(0, 365, N), unit="D"
)

df = pd.DataFrame({
    "EmployeeID": [f"EMP{100000 + i}" for i in range(1, N + 1)],
    "Age": age,
    "Gender": gender,
    "MaritalStatus": marital,
    "Education": education,
    "EducationField": education_field,
    "Department": department,
    "JobRole": job_role,
    "JobLevel": job_level,
    "Location": location,
    "WorkMode": work_mode,
    "DistanceFromHome": distance,
    "BusinessTravel": business_travel,
    "OverTime": overtime,
    "MonthlyIncome": monthly_income,
    "PercentSalaryHike": salary_hike,
    "TotalWorkingYears": total_working_years,
    "NumCompaniesWorked": num_companies,
    "YearsAtCompany": years_at_company,
    "YearsInCurrentRole": years_in_role,
    "YearsSinceLastPromotion": years_since_promo,
    "YearsWithCurrManager": years_with_manager,
    "TrainingTimesLastYear": training,
    "JobSatisfaction": job_sat,
    "EnvironmentSatisfaction": env_sat,
    "RelationshipSatisfaction": rel_sat,
    "WorkLifeBalance": wlb,
    "PerformanceRating": performance,
    "HireDate": hire_date.strftime("%Y-%m-%d"),
    "Attrition": attrition,
})

# Real data is never perfectly clean: blank out a small share of two columns
# so the analysis script has a genuine cleaning step to demonstrate.
for col, share in [("EnvironmentSatisfaction", 0.010), ("DistanceFromHome", 0.008)]:
    missing_idx = rng.choice(N, int(N * share), replace=False)
    df[col] = df[col].astype("Int64")
    df.loc[missing_idx, col] = pd.NA

out = Path(__file__).resolve().parent.parent / "data" / "hr_employee_data.csv"
out.parent.mkdir(exist_ok=True)
df.to_csv(out, index=False)

print(f"Saved {len(df):,} rows x {df.shape[1]} columns -> {out}")
print(f"Overall attrition rate: {(df['Attrition'] == 'Yes').mean():.1%}")
